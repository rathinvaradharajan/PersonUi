declare function verifyProvider(opts: any): Promise<void>;
export = verifyProvider;
