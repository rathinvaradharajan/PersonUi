export function info(msg: string): void;
